Steps to edit the UML and Sequence diagrams:

1. VS Code Install
Installation
-> Download the Visual Studio Code installer for Windows.
-> Once it is downloaded, run the installer (VSCodeUserSetup-{version}.exe). This will only take a minute.
-> By default, VS Code is installed under C:\users\{username}\AppData\Local\Programs\Microsoft VS Code.

Alternatively, you can also download a Zip archive, extract it and run Code from there.

Note: .NET Framework 4.5.2 or higher is required for VS Code. If you are using Windows 7, make sure you have at least .NET Framework 4.5.2 installed. You can check your version of .NET Framework using this command, reg query "HKEY_LOCAL_MACHINE\SOFTWARE\Microsoft\NET Framework Setup\NDP\v4\full" /v version from a command prompt.

2. PlantUML Integration
PlantUML supports a wide range of IDE integrations. All the supported IDEs are listed on the official PlantUML website, http://plantuml.com/running.
We opt for VS Code since it�s running hot lately and there is no sign of stopping it. Before installing PlantUML extension on VS Code, make sure you have the following prerequisites:
� Java
� GraphViz

You can search and install PlantUML extension from the Extensions tab. It�s available in the Visual Studio Marketplace.

3. Coding
In PlantUML we use a pseudo-programming language to generate diagrams. This code file can have one of the following file extensions:
*.wsd, *.pu, *.puml, *.plantuml, *.iuml

Refer below link for PlantUML coding documentation:
http://plantuml.com/guide

4. Exporting
PlantUML supports exporting diagrams into different file formats. The following are some of the supported types:
*.png, *.svg, *eps, *.pdf, *vdx, *.xmi, *scmi, *html, *.txt, *.utxt, *.latex



